# ECE 745 Project 3 Run Instructions

1. Run `make regress` to collect coverage based on the test plan
2. Run `make view_coverage` to view coverage collected
